class FlightDetail < ApplicationRecord
    
end
