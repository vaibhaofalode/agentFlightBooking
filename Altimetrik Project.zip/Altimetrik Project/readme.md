# Agent Application for Flight Booking

Foobar is a Python library for dealing with word pluralization.

## Installation

Filter will be having following options

•	Source City (required)

•	Destination City (required)

•	Travel Date (required)

•	Return Date(Optional)

